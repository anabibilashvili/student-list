import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Employee } from '../employee.interface';

@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.scss']
})
export class EmployeeDetailComponent implements OnInit {

  @Input() employee: Employee | undefined | null;
  @Output() saveEvent = new EventEmitter<Employee | undefined | null>();

  constructor() { }

  ngOnInit(): void {
  }

  save() {
    if (this.employee) {
      if (this.employee.firstName && this.employee.lastName) {
        this.saveEvent.emit(this.employee);
      }
    }
  }

}
