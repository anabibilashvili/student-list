import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee.interface';
import { EMPLOYEES } from '../mock-employees';
import { faArchive, faUserPlus } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit {

  faArchive = faArchive;
  faUserPlus = faUserPlus;
  employees: Employee[] = [];
  selectedEmployee: Employee | undefined | null;
  showUserForm: boolean = false;
  employeeToAdd: Employee = {
    id: 0,
    firstName: '',
    lastName: '',
    salary: 0,
    hireDate: new Date(),
    positionName: ''
  };

  constructor() { }

  ngOnInit(): void {
    console.log("init")
    this.employees = EMPLOYEES;
  }

  selectEmployee(id: number) {
    //this.selectedUser = this.users.find(e => e.id == id);
    const selectedEmployee = this.employees.find(e => e.id == id);
    this.selectedEmployee = Object.assign({}, selectedEmployee);
  }

  save(user: Employee | undefined | null) {
    if (user && user.firstName && user.lastName) {
      //1st way
      const id = user.id;
      const indx = this.employees.findIndex(e => e.id === id);
      if (indx > -1) {
        this.employees[indx] = user;
      }

      //2nd way
      /*let selectedUser = this.users.find(e => e.id == id);
      if (selectedUser) {
        selectedUser.name = this.selectedUser.name;
      }*/
    }
  }

  deleteEmployee(id: number) {
    const indx = this.employees.findIndex(e => e.id == id);
    if (indx > -1) {
      this.employees.splice(indx, 1);
      this.selectedEmployee = null;
    }
  }

  showAddUserForm() {
    this.selectedEmployee = null;
    this.showUserForm = true;
  }

  addUser() {
    if (this.employeeToAdd.firstName && this.employeeToAdd.lastName) {
      let maxId = 0;
      for (let i = 0, l = this.employees.length; i < l; i++) {
        if (this.employees[i].id > maxId) {
          maxId = this.employees[i].id;
        }
      }
      this.employeeToAdd.id = ++maxId;
      this.employees.push(this.employeeToAdd);
      this.showUserForm = false;
      //this is to clear form when add user again
      this.employeeToAdd = {
        id: 0,
        firstName: '',
        lastName: '',
        salary: 0,
        hireDate: new Date(),
        positionName: ''
      };
    }
  }

}
