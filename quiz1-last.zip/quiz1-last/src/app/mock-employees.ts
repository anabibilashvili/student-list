import { Employee } from './employee.interface';

export const EMPLOYEES: Employee[] = [{
  id: 1,
  firstName: 'გიორგი',
  lastName: 'ბერიძე',
  salary: 1000,
  hireDate: new Date(2021, 0, 1),
  positionName: 'director'

}, {
  id: 2,
  firstName: 'ანრი',
  lastName: 'მორჩილაძე',
  salary: 1000,
  hireDate: new Date(2021, 0, 2),
  positionName: 'manager'

}];
